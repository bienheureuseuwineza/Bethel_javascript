var groceryList = ["Bananas", "Milk", "Eggs", "Bacon"];
var message = "Please pick up the following from the store: ";

for (var i = 0; i < groceryList.length; i++) {
  console.log(
    message,
    groceryList[0],
    ",",
    groceryList[1],
    ",",
    groceryList[2],
    ",",
    groceryList[3]
  );
}
